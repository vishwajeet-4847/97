export const formatDate = (date) => {
    return date.toLocaleDateString('en-CA'); // 'yyyy-mm-dd' format
  };